# Pre-ship security and sanity review

**Category:** Shipping

**Use it when:** Before you share the link with real users, or before every launch. Pair it with the pre-deploy checklist in this pack.

Replace every [BRACKET] before you paste it.

## Prompt

````text
Read AGENTS.md first. This is a review: don't change code until I approve a fix list.

Review this app as if it's about to get its first 1,000 strangers. Check:
1. Secrets: any API keys, tokens or passwords in the code, in git history, or sent to the browser? Which env vars are exposed to the client?
2. Auth: can a logged-out user reach pages or API routes they shouldn't? Can user A read or change user B's data by changing an ID in the URL or request?
3. Database: are access rules (e.g. row-level security) on for every table that holds user data?
4. Input: anywhere user input goes into a query, HTML, a file path or a shell command without validation?
5. Costs: any endpoint that calls a paid API (AI, email, SMS) with no login or rate limit?
6. Errors: do error messages leak stack traces or internal details to users?
7. Basics: 404 page, broken links, forms that fail silently, missing loading or error states.

Output a table: issue, severity (critical / high / medium / low), file and line, and the suggested fix. Critical first. Then wait for my OK on which ones to fix.
````

## Why it works

AI builders ship working features fast but rarely check who else can call them. These seven areas cover the mistakes behind most painful launch-day surprises: leaked keys, open data, and surprise API bills.

---
From the free Loot Drop Starter Loadout: https://lootdrop.tools/armory/starter-loadout/prompts/#07-pre-ship-review
