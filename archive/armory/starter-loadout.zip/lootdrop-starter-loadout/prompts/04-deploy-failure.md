# Deploy failure fix

**Category:** Shipping

**Use it when:** It works on your machine (or in the builder's preview) but the deploy on Vercel, Netlify, Cloudflare, Railway or Render fails, or the live site shows a blank page.

Replace every [BRACKET] before you paste it.

## Prompt

````text
Read AGENTS.md first.

It works locally but fails on [hosting provider].
Deploy log or live error (unedited):
```
[paste]
```

Check these in order and tell me what you find for each before fixing anything:
1. Build command, output directory and Node/Python version the host uses vs. what the project needs (package.json engines, .nvmrc, runtime files).
2. Environment variables: list every one the code reads, and mark which are missing or named differently on the host. Remember that client-side variables often need a prefix (NEXT_PUBLIC_, VITE_, etc.).
3. Case-sensitive import paths (works on Mac/Windows, fails on Linux).
4. Code that only works locally: localhost URLs, files written to disk, dev-only dependencies used at runtime.
5. Lockfile and package manager mismatches.

Then: run the production build locally (`[npm run build]`) and confirm it passes, make the smallest fix, and give me the exact settings I need to change in the host dashboard (if any) as a checklist. Never put secret values in the code or the reply.
````

## Why it works

Most "works locally, fails on deploy" bugs fall into the same handful of buckets. A fixed checklist stops the agent rewriting app code when the real fix is a missing env var or a dashboard setting.

---
From the free Loot Drop Starter Loadout: https://lootdrop.tools/armory/starter-loadout/prompts/#04-deploy-failure
