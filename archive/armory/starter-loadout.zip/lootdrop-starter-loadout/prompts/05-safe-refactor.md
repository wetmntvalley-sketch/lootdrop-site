# Safe refactor

**Category:** Refactoring

**Use it when:** A file has grown into a monster (500+ lines, copy-pasted blocks) and you want it cleaner without breaking anything.

Replace every [BRACKET] before you paste it.

## Prompt

````text
Read AGENTS.md first.

Refactor [file or folder]. Goal: [easier to read / split into smaller pieces / remove duplication]. Behavior must not change at all: same inputs, same outputs, same UI.

Rules:
1. First, tell me how we'll know nothing broke. If tests don't cover this code, write a few tests that pin down what it does TODAY (including any weird behavior) and get them passing before you refactor.
2. Give me a plan of small steps. Each step should leave the app working.
3. Do one step at a time. After each step, run the tests and the type check.
4. No new features, no bug fixes, no dependency changes, no renaming of anything other files import, unless I approve it. If you spot a bug, list it at the end instead of fixing it.
5. Finish with a before/after summary: what moved where, and the test results.
````

## Why it works

Refactors go wrong when behavior changes sneak in alongside the cleanup. Pinning current behavior with tests first, then moving in small verified steps, makes it reversible at every point.

---
From the free Loot Drop Starter Loadout: https://lootdrop.tools/armory/starter-loadout/prompts/#05-safe-refactor
