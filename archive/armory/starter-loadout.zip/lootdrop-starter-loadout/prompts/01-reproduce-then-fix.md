# Reproduce, then fix

**Category:** Debugging

**Use it when:** Something is broken and you can describe what you expected versus what happened. Use it instead of "fix this".

Replace every [BRACKET] before you paste it.

## Prompt

````text
Read AGENTS.md first.

Bug: [what you did] -> [what you expected] -> [what happened instead].
Error text, if any (copied exactly):
[paste error or "none"]

Work in this order and don't skip ahead:
1. Reproduce it. Tell me the exact steps or command that shows the bug, and what output proves it's happening.
2. Find the cause. Name the file and line, and explain in 2-3 plain sentences why it happens. If you have more than one theory, list them, most likely first, and say how you ruled the others out.
3. Fix only the cause. Smallest change that works. No refactors, no new dependencies.
4. Prove it. Re-run the reproduction and show it now passes. Run lint, type check and tests.
5. Report: files changed (one line each), how you verified it, and anything you're unsure about.

If you can't reproduce it, stop after step 1 and tell me what you tried and what extra info you need.
````

## Why it works

Agents that patch before reproducing tend to fix a symptom and break something nearby. Forcing a reproduction first gives the agent (and you) proof the fix actually worked.

---
From the free Loot Drop Starter Loadout: https://lootdrop.tools/armory/starter-loadout/prompts/#01-reproduce-then-fix
