# Tests for code you didn't write

**Category:** Refactoring

**Use it when:** Your AI-built app has zero tests and you're scared to change anything. Run this on the most important flow first (signup, checkout, saving data).

Replace every [BRACKET] before you paste it.

## Prompt

````text
Read AGENTS.md first.

Add tests for [feature or file, e.g. "the signup flow" or "src/lib/cart.ts"]. Don't change any app code.

1. Read the code and list what it currently does as plain-English rules ("If the email is already taken, it shows 'Account exists'"). Include edge cases: empty input, wrong types, network errors, logged-out users.
2. Use the test setup we already have ([test framework]). If there is none, suggest the lightest option for our stack and wait for my OK before installing anything.
3. Write tests that pass against the CURRENT code. If you find behavior that looks like a bug, still test what it does now, mark the test with a "BUG?" comment, and list it for me.
4. Run the tests and show me the results.
5. Tell me which important paths are still untested.
````

## Why it works

"Characterization" tests record what the code really does, not what it should do, so they catch any change. They're the safety net that makes every other prompt in this pack less risky.

---
From the free Loot Drop Starter Loadout: https://lootdrop.tools/armory/starter-loadout/prompts/#06-characterization-tests
