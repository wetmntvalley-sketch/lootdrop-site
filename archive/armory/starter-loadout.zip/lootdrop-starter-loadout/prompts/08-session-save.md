# Session save (handoff)

**Category:** Shipping

**Use it when:** At the end of every work session, or before switching tools or models. It keeps the next session from starting cold.

Replace every [BRACKET] before you paste it.

## Prompt

````text
We're wrapping up this session. Don't change any app code.

Update AGENTS.md:
1. Under "Known gotchas", add anything we tripped over today that would trip up the next session (one line each). Don't duplicate what's already there.
2. Under "Commands" or "Project map", fix anything that's now out of date.
3. Under "Progress log", add one line at the top for today: what got done, and the next step.

Then give me a short handoff note I can paste into a fresh chat:
- What we were working on and where it stands
- What's verified working vs. not yet verified
- Open questions and known bugs
- The exact next step

Show me the AGENTS.md diff before saving it.
````

## Why it works

Context dies when a chat ends or you switch tools. Writing it back into AGENTS.md is the "save file" from The Drop #1's quest: your next session, or your next tool, picks up where you left off.

---
From the free Loot Drop Starter Loadout: https://lootdrop.tools/armory/starter-loadout/prompts/#08-session-save
