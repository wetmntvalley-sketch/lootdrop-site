# Error log triage

**Category:** Debugging

**Use it when:** You have a wall of red text (stack trace, build log, browser console) and don't know which line matters.

Replace every [BRACKET] before you paste it.

## Prompt

````text
Read AGENTS.md first. Don't change any code yet.

Here is the full log, unedited:
```
[paste the whole log]
```

1. Quote the one line that is the real root error (not a follow-on error), and explain in plain English what it means.
2. Point to the file and line in OUR code where it starts (ignore library internals unless the cause really is there).
3. Give me the 3 most likely causes, most likely first, each with one quick check I can run or you can run to confirm it.
4. Run those checks yourself if you can, then tell me which cause it is.
5. Propose a fix and wait for my OK before editing anything.
````

## Why it works

Long logs make agents latch onto the last error, which is usually a side effect. Asking for the first real error plus a ranked list of causes with checks turns guessing into a short elimination.

---
From the free Loot Drop Starter Loadout: https://lootdrop.tools/armory/starter-loadout/prompts/#02-error-log-triage
