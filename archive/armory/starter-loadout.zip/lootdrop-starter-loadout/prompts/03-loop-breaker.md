# Loop breaker

**Category:** Debugging

**Use it when:** The agent has "fixed" the same bug two or three times and it keeps coming back, or it keeps undoing its own changes.

Replace every [BRACKET] before you paste it.

## Prompt

````text
Stop editing. We're in a loop.

Before you touch any more code:
1. List every fix you've tried for this so far, and what happened after each one.
2. Tell me what those failures prove is NOT the cause.
3. List assumptions you've been making that you haven't actually verified (versions, env vars, which file is really running, cached builds, the data in the database).
4. Pick the single assumption most likely to be wrong and tell me how to check it with one command or one log line.
5. Run that check and report what it shows.

Then propose ONE new approach that is different in kind from what you've already tried, not a variation of it. Wait for my OK before you make changes. If you think the honest answer is "I need information I don't have", say exactly what it is.
````

## Why it works

Loops usually come from one wrong assumption the agent never re-checks. Making it write down what failed and what it assumed breaks the pattern, and stopping for approval stops it piling more edits on top.

---
From the free Loot Drop Starter Loadout: https://lootdrop.tools/armory/starter-loadout/prompts/#03-loop-breaker
