# CLAUDE.md

Read `AGENTS.md` in the repo root first, and follow it. It is the single source of truth for this project's stack, commands, rules and definition of done.

If anything here conflicts with `AGENTS.md`, `AGENTS.md` wins. Put new project notes in `AGENTS.md`, not here, so every tool sees them.
