# AGENTS.md

<!--
Loot Drop Starter Loadout: AGENTS.md "save file" template, v1 (Oct 2026).
Fill in every [BRACKET]. Delete any section that doesn't apply.
Keep it short: aim for under 150 lines. Agents read all of it on every task,
so every line should change what they do.
-->

## Project
- **What it is:** [One sentence. Example: "A habit tracker web app for people who keep forgetting to drink water."]
- **Who uses it:** [Example: "Logged-in users on phones, mostly."]
- **Status:** [prototype / beta with real users / in production]. [If real users: "Treat the database and auth as production. Don't break them."]

## Stack
- **Language and framework:** [Example: TypeScript, Next.js 15 (App Router), React 19]
- **Styling:** [Example: Tailwind CSS v4. No other CSS libraries.]
- **Data and auth:** [Example: Supabase (Postgres plus Auth). Row-level security is ON.]
- **Hosting:** [Example: Vercel. The production branch is `main`.]
- **Package manager:** [npm / pnpm / bun / pip / uv]. Use only this one. Don't create a second lockfile.

## Commands
Run these from the repo root. If a command fails, fix the cause; don't skip the step.

| Task | Command |
|---|---|
| Install | `[npm install]` |
| Dev server | `[npm run dev]` (serves at `[http://localhost:3000]`) |
| Lint | `[npm run lint]` |
| Type check | `[npx tsc --noEmit]` |
| Tests | `[npm test]` |
| Production build | `[npm run build]` |

## Project map
- `[src/app/]`: [routes and pages]
- `[src/components/]`: [shared UI components]
- `[src/lib/]`: [data access, helpers, API clients]
- `[supabase/migrations/]`: [database migrations; never edit an old one, add a new one]
- [Add anything an agent would otherwise have to go looking for.]

## Hard rules
1. **Never commit secrets.** API keys live in `.env.local` (git-ignored). Read them through `[process.env.X]`. If you need a new secret, add it to `.env.example` with an empty value and tell me.
2. **No new dependencies without asking.** Say which package, why, and what the alternative without it would be.
3. **Don't touch these files unless I ask:** `[.env*, supabase/migrations/* (existing ones), package-lock.json by hand, LICENSE]`.
4. **Small diffs.** Change only what the task needs. No drive-by reformatting, renames or "while I'm here" refactors.
5. **Don't delete or weaken tests to make them pass.** If a test is wrong, say why and ask first.
6. **Don't disable security to make something work:** no turning off row-level security, CORS `*`, `--no-verify`, or `any` casts to silence type errors.
7. **Ask before anything destructive:** dropping tables, deleting data, force-pushing, rewriting git history, or changing auth settings.

## Conventions
- [Example: Server components by default; add `"use client"` only when a component needs state or browser APIs.]
- [Example: All database access goes through `src/lib/db.ts`. Don't call the database client from components.]
- [Example: Dates are stored in UTC and shown in the user's local time.]
- Match the style of the code around you. When in doubt, copy the nearest similar file.

## Definition of done
A task is done only when all of these are true:
- [ ] The thing I asked for works, and you've said how you checked it (command output, or the exact steps you clicked through).
- [ ] Lint, type check and tests pass. If something was already failing before you started, say so.
- [ ] The production build passes (`[npm run build]`).
- [ ] No secrets, debug `console.log`s or commented-out code left behind.
- [ ] You've listed every file you changed, with one line each on why.
- [ ] Anything you weren't sure about is listed under "Open questions" at the end of your reply.

## How to work with me
- I'm [a non-coder / a beginner / comfortable with code]. Explain changes in [plain English / brief technical terms].
- For bugs: reproduce first, then fix. Don't guess-and-patch.
- If you've tried the same fix twice and it still fails, stop and tell me what you've learned instead of trying a third variation.
- Before a big change (more than about 5 files, or anything touching auth, payments or the database schema), write a short plan and wait for my OK.

## Known gotchas
<!-- Add one line every time an agent trips over the same thing twice. This section is the "save file". -->
- [Example: Local dev needs `SUPABASE_URL` and `SUPABASE_ANON_KEY` in `.env.local`, or every page shows a blank screen.]
- [Example: The build fails if you import server-only code into a client component. Check `"use client"` boundaries first.]

## Progress log
<!-- Optional. One line per session so the next session (or the next tool) knows where things stand. Newest first. -->
- [2026-10-15] [Set up AGENTS.md. Next: fix the signup redirect loop.]
