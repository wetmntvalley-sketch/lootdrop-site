# Pre-deploy checklist

Run through this before you share a link with real users. Tick every box or write down why it doesn't apply.

## Secrets and config
- [ ] No API keys, tokens or passwords in the code. Search the repo for `sk-`, `key`, `secret`, `token`, `password`.
- [ ] `.env` files are in `.gitignore`, and were never committed (check git history too).
- [ ] Every environment variable the app needs is set on the host, with production values.
- [ ] Only variables that are safe to be public are exposed to the browser.

## Auth and data
- [ ] Logged-out users can't open private pages or call private API routes.
- [ ] User A can't see or change user B's data by editing an ID in the URL or request.
- [ ] Database access rules (for example row-level security) are on for every table with user data.
- [ ] Password reset and email confirmation links point to the live domain, not localhost.

## Money and limits
- [ ] Every endpoint that calls a paid API (AI, email, SMS) requires login and has a rate limit.
- [ ] Spending limits or budget alerts are set on every paid API account.
- [ ] Payments: test mode is off in production, and webhooks point at the live URL.

## Build and hosting
- [ ] The production build passes locally (`npm run build` or equivalent).
- [ ] The host uses the same runtime version as your machine (Node, Python).
- [ ] Custom domain works with HTTPS, with and without `www`.

## User-facing basics
- [ ] Every form shows a success message and a useful error message.
- [ ] There's a 404 page and no broken links in the nav or footer.
- [ ] Pages work on a phone-width screen (about 390px).
- [ ] Error pages don't show stack traces or internal details.
- [ ] There's a way for users to contact you.

## After deploy
- [ ] Sign up, log in, do the main action, and log out on the live site, using a fresh account.
- [ ] Check the host's logs for errors after that test run.
- [ ] Run the "Session save" prompt so AGENTS.md records what shipped.
