# Loot Drop Starter Loadout (free)

Weekly loot for AI builders: https://lootdrop.tools

A small, copy-paste kit for vibe-coded apps (Cursor, Claude Code, Codex, Lovable,
Bolt, Replit, v0 exports and friends). Readable online at
https://lootdrop.tools/armory/starter-loadout/

## What's inside

| File | What it does |
|---|---|
| `AGENTS.md` | The "save file": a fill-in-the-blanks project brief every coding agent reads first (stack, commands, hard rules, definition of done). |
| `CLAUDE.md` | Two-line pointer so Claude Code reads AGENTS.md. |
| `.cursor/rules/agents.mdc` | Always-on Cursor project rule that points to AGENTS.md. |
| `.cursorrules` | Same pointer for older Cursor versions. |
| `prompts/` | 8 prompt templates for debugging, refactoring and shipping. |
| `CHECKLIST.md` | Pre-deploy checklist to run before real users show up. |

Note: `.cursor/` and `.cursorrules` start with a dot, so Finder and some file
explorers hide them. On a Mac press Cmd+Shift+. to show hidden files.

## Install (about 3 minutes)

1. Copy `AGENTS.md`, `CLAUDE.md`, `.cursorrules` and the `.cursor/` folder into
   your repo root. If you already have a `.cursor/rules/` folder, just add
   `agents.mdc` to it.
2. Fill in every [BRACKET] in AGENTS.md and delete sections you don't need.
   Faster: ask your agent "Read this repo and fill in AGENTS.md. Ask me about
   anything you can't find out from the code."
3. Keep `prompts/` and `CHECKLIST.md` wherever you like (they don't need to be
   in the repo). Paste a prompt into your agent whenever you need it, and
   replace the [BRACKETS] first.

## How to use the prompts

- Start every new chat with the relevant prompt instead of "fix this".
- Paste errors exactly. Don't summarize them.
- End every session with `08-session-save.md` so the next session starts warm.

## Honest status

These templates follow the same checks we use in The Drop's quests, but they
haven't been scored in a published Drop test yet. When they are, results and
any changes will be posted at https://lootdrop.tools/armory/starter-loadout/

## License

See LICENSE.txt. Use it, change it, ship it.

Questions or fixes: thedrop@mail.grokbot.com
