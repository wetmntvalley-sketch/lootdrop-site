extends Area2D


func _on_body_entered(body: Node2D) -> void:
	if body.name == "Hero":
		Game.add_score(10)
		print("Coin! Score: ", Game.score)
		queue_free()
