extends Node

var score = 0
var lives = 3
var level = 1

func reset():
	score = 0
	lives = 3
	level = 1

func add_score(points):
	score += points

func lose_life():
	lives -= 1
	if lives <= 0:
		get_tree().call_deferred("change_scene_to_file", "res://game_over.tscn")
		return false
	return true

func beat_level():
	if level == 1:
		level = 2
		get_tree().call_deferred("change_scene_to_file", "res://world2.tscn")
	else:
		get_tree().call_deferred("change_scene_to_file", "res://you_win.tscn")
