extends Control

func _ready():
	Game.reset()

func _process(_delta):
	if Input.is_action_just_pressed("ui_accept"):
		start_game()

func start_game():
	Game.reset()
	get_tree().change_scene_to_file("res://world.tscn")


func _on_play_button_pressed() -> void:
	start_game()
