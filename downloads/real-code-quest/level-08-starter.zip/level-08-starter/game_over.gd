extends Control

func _ready():
	$ScoreLabel.text = "Score: " + str(Game.score)

func _process(_delta):
	if Input.is_action_just_pressed("ui_accept"):
		get_tree().change_scene_to_file("res://title.tscn")
