extends CharacterBody2D

var gravity = 350
var run_speed = 120
var jump_speed = -250
var falls = 0
var finish_x = 1000
var finished = false
var bonks = 0

func _physics_process(delta):
	velocity.y += gravity * delta
	var direction = Input.get_axis("ui_left", "ui_right")
	velocity.x = direction * run_speed
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = jump_speed
	move_and_slide()
	if position.y > 200:
		respawn()
	if position.x > finish_x and not finished:
		finished = true
		print("You made it! Falls: ", falls)

func respawn():
	position = Vector2(80, 40)
	velocity = Vector2.ZERO
	falls += 1
	print("Oops! Falls: ", falls)
