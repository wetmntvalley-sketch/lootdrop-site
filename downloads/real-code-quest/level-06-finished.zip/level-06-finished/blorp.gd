extends CharacterBody2D

var gravity = 350
@export var speed = 30
var direction = -1
@export var patrol = 40
var start_x = 0

func _ready():
	start_x = position.x

func _physics_process(delta):
	velocity.y += gravity * delta
	velocity.x = speed * direction
	move_and_slide()
	if position.x < start_x - patrol:
		direction = 1
	if position.x > start_x + patrol:
		direction = -1
	if is_on_wall():
		direction = direction * -1
	$Sprite2D.flip_h = direction > 0


func _on_hit_area_body_entered(body: Node2D) -> void:
	if body.name == "Hero":
		if body.position.y < position.y - 8:
			body.velocity.y = -200
			body.bonks += 1
			print("Bonk! Blorps bonked: ", body.bonks)
			queue_free()
		else:
			body.respawn()
