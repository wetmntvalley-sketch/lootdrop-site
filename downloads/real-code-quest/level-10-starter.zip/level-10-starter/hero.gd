extends CharacterBody2D

var gravity = 350
var run_speed = 120
var jump_speed = -250
var falls = 0
@export var finish_x = 1000
var finished = false
var bonks = 0
var juice_tween: Tween
var shake_time = 0.0
var shake_strength = 0.0

func _physics_process(delta):
	velocity.y += gravity * delta
	var direction = Input.get_axis("ui_left", "ui_right")
	velocity.x = direction * run_speed
	var falling = velocity.y > 40
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = jump_speed
		stretch()
		Sfx.jump()
	move_and_slide()
	if falling and is_on_floor():
		squash()
		Sfx.land()
		puff_at(global_position + Vector2(0, 7))
	if shake_time > 0.0:
		shake_time -= delta
		$Camera2D.offset = Vector2(
			randf_range(-shake_strength, shake_strength),
			randf_range(-shake_strength, shake_strength)
		)
		if shake_time <= 0.0:
			$Camera2D.offset = Vector2.ZERO
	if position.y > 200:
		respawn()
	if position.x > finish_x and not finished:
		finished = true
		print("You made it! Falls: ", falls)
		Game.beat_level()

func squash():
	_juice_scale(Vector2(1.35, 0.65))

func stretch():
	_juice_scale(Vector2(0.7, 1.35))

func _juice_scale(to_scale):
	if juice_tween:
		juice_tween.kill()
	$Sprite2D.scale = to_scale
	juice_tween = create_tween()
	juice_tween.set_process_mode(Tween.TWEEN_PROCESS_PHYSICS)
	juice_tween.tween_property($Sprite2D, "scale", Vector2.ONE, 0.12).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)

func start_shake(time=0.2, strength=3.0):
	shake_time = time
	shake_strength = strength

func puff_at(where):
	var puff = preload("res://puff.tscn").instantiate()
	puff.global_position = where
	# World is the hero's parent.
	get_parent().add_child(puff)

func respawn():
	position = Vector2(80, 40)
	velocity = Vector2.ZERO
	falls += 1
	print("Oops! Falls: ", falls)
	$Sprite2D.scale = Vector2.ONE
	$Camera2D.offset = Vector2.ZERO
	start_shake(0.2, 3.0)
	Sfx.hurt()
	Game.lose_life()
