extends CanvasLayer

func _process(_delta):
	$ScoreLabel.text = "Score: " + str(Game.score)
	# Boss Bonus 2: hearts show lives. Hide the leftover text label.
	$LivesLabel.visible = false
	$Heart1.visible = Game.lives >= 1
	$Heart2.visible = Game.lives >= 2
	$Heart3.visible = Game.lives >= 3
