extends Node2D

var speed = 100

func _ready():
	print("Hello, Godot!")
	
func _process(delta):
	var direction = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	position += direction * speed * delta

	if position.x > 160:
		position.x = -16
	if position.x < -16:
		position.x = 160
