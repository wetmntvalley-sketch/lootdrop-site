extends Node

var score = 0
var lives = 3
var level = 1
var high_score = 0
var volume = 1.0
const SAVE_PATH = "user://save.cfg"

func _ready():
	load_game()
	apply_volume()

func reset():
	score = 0
	lives = 3
	level = 1

func add_score(points):
	score += points

func lose_life():
	lives -= 1
	if lives <= 0:
		get_tree().call_deferred("change_scene_to_file", "res://game_over.tscn")
		return false
	return true

func beat_level():
	if level == 1:
		level = 2
		get_tree().call_deferred("change_scene_to_file", "res://world2.tscn")
	else:
		get_tree().call_deferred("change_scene_to_file", "res://you_win.tscn")

func save_game():
	var config = ConfigFile.new()
	config.set_value("player", "high_score", high_score)
	config.set_value("player", "volume", volume)
	config.save(SAVE_PATH)

func load_game():
	var config = ConfigFile.new()
	var err = config.load(SAVE_PATH)
	if err != OK:
		return
	high_score = config.get_value("player", "high_score", 0)
	volume = config.get_value("player", "volume", 1.0)
	print("Loaded from ", OS.get_user_data_dir())

func apply_volume():
	if volume <= 0.0:
		AudioServer.set_bus_volume_db(0, -80)
	else:
		AudioServer.set_bus_volume_db(0, linear_to_db(volume))

func check_high_score():
	if score > high_score:
		high_score = score
		save_game()
		return true
	return false
