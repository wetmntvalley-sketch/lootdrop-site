extends Area2D


func _on_body_entered(body: Node2D) -> void:
	if body.name == "Hero":
		set_deferred("monitoring", false)
		Game.add_score(10)
		print("Coin! Score: ", Game.score)
		Sfx.coin()
		var puff = preload("res://puff.tscn").instantiate()
		puff.global_position = global_position
		get_parent().add_child(puff)
		queue_free()
