extends Control

func _ready():
	$ScoreLabel.text = "Score: " + str(Game.score)
	if Game.check_high_score():
		$HighScoreLabel.text = "New high score!"
	else:
		$HighScoreLabel.text = "High score: " + str(Game.high_score)

func _process(_delta):
	if Input.is_action_just_pressed("ui_accept"):
		get_tree().change_scene_to_file("res://title.tscn")
