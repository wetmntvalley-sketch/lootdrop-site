extends Control

func _ready():
	Game.reset()
	$HighScoreLabel.text = "High score: " + str(Game.high_score)
	$VolumeSlider.value = Game.volume

func _process(_delta):
	if Input.is_action_just_pressed("ui_accept"):
		start_game()

func start_game():
	Game.reset()
	get_tree().change_scene_to_file("res://world.tscn")


func _on_play_button_pressed() -> void:
	start_game()


func _on_volume_slider_value_changed(value: float) -> void:
	Game.volume = value
	Game.apply_volume()
	Game.save_game()


func _on_beep_button_pressed() -> void:
	$Beep.play()


func _on_mute_button_pressed() -> void:
	if Game.volume > 0.0:
		Game.volume = 0.0
	else:
		Game.volume = 1.0
	$VolumeSlider.value = Game.volume
	Game.apply_volume()
	Game.save_game()
