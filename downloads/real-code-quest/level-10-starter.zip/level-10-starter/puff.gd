extends GPUParticles2D

func _ready():
	finished.connect(queue_free)
	restart()
	emitting = true
	# If finished never arrives (some machines, or the game is paused),
	# still clean the puff up after the burst.
	get_tree().create_timer(lifetime + 0.2).timeout.connect(queue_free)
