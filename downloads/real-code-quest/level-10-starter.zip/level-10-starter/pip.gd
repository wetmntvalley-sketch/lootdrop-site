extends Area2D


func _on_body_entered(body: Node2D) -> void:
	if body.name == "Hero":
		if body.bonks >= 3:
			$Bubble.text = "Wow! You bonked them all!"
		$Bubble.show()


func _on_body_exited(body: Node2D) -> void:
	if body.name == "Hero":
		$Bubble.hide()
