extends Node

func jump():
	$Jump.play()

func coin():
	$Coin.play()

func bonk():
	$Bonk.play()

func hurt():
	$Hurt.play()

func land():
	$Land.play()
